function u(t,n,e=!0){return n===t.length-1?e?t[0]:t[n]:t[n+1]}function f(t,n,e=!0){return n<=0?e?t[t.length-1]:t[0]:t[n-1]}function l(t){return t[t.length-1]}export{l,u as n,f as p};

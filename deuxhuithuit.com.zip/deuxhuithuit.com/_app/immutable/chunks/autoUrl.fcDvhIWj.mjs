import{g as u}from"./getEntryUrl.zQssKiXQ.mjs";const i=(r,o)=>{if(!r)return null;const{id:s,__typename:t}=r;return t!=null&&t.startsWith("module")?`#${s}`:u(r,o).toSchemeLess()};export{i as a};

const s=n=>n?n.split("-")[0]:null,t=["en-ca","fr-ca"],o=t,a=o.map(s);a[0];const c=o.length>=2,e="America/Toronto",r="__home__";export{r as H,c as I,a as S,e as T};

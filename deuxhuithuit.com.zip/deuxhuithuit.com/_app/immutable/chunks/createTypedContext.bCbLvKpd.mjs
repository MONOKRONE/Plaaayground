import{e as o,f as n}from"./scheduler.e7n1CwD9.mjs";const s=t=>({getContext:()=>o(t),setContext:e=>n(t,e)});export{s as c};

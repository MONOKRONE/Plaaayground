import{o as r}from"./scheduler.e7n1CwD9.mjs";const e={subscribe(o){return o(!1),r(()=>o(!0)),()=>{}}};export{e as m};

const o=e=>(Number(e)/10).toFixed(1);export{o as p};

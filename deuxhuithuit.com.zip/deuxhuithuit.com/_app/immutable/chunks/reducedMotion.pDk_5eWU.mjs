const e=()=>typeof window<"u"&&window.matchMedia("(prefers-reduced-motion)").matches;export{e as r};

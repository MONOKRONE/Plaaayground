import{f as a}from"../chunks/entry.EFDYqbg4.mjs";export{a as start};
